<!-- category tabs -->
<nav class="tabs">
    <ul>
        <li id="add-new-tab" class="hover-tab0"><a href="add-new.php">Add New!</a></li>
        <li id="index-tab" class="hover-tab1"><a href="home.php"><i class="fa-solid fa-house"></i></a></li>
        <li id="apps-tab" class="hover-tab2"><a href="apps.php">Apps</a></li>
        <li id="mains-tab" class="hover-tab3"><a href="mains.php">Mains</a></li>
        <li id="sides-tab" class="hover-tab4"><a href="sides.php">Sides</a></li>
        <li id="desserts-tab" class="hover-tab5"><a href="desserts.php">Desserts</a></li>
        <li id="drinks-tab" class="hover-tab6"><a href="drinks.php">Drinks</a></li>
        <li id="sauces-tab" class="hover-tab7"><a href="sauces.php">Sauces</a></li>
    </ul>
</nav>
