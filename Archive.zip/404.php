<!doctype html>
<html lang="en">
<head>
    <?php include './meta.php'; ?>
    <title>404 Error</title>
</head>
<html>
<body>
<main>
    <h1>404 error Resource not found</h1>
</main>
</body>
</html>